from settings import *
import pygame
import math
import time

class Player:
    def __init__(self, game):
        self.game = game
        self.X, self.Y = Player_Pos
        self.Angle = Player_Angle
        self.shot = False
        
    def fire_event(self, event):
        if event.type == pygame.MOUSEBUTTONDOWN:
            if event.button == 1 and not self.shot and not self.game.weapon.reloading:
                self.shot = True
                self.game.weapon.reloading = True
                self.check_wall_collision(-RECOIL * math.cos(self.Angle), -RECOIL * math.sin(self.Angle))
                
        
    def movement(self):
        sin_a = math.sin(self.Angle)
        cos_a = math.cos(self.Angle)
        dx, dy = 0, 0
        speed = Player_Speed * self.game.delta_time
        speed_sin = speed * sin_a
        speed_cos = speed * cos_a
        
        key = pygame.key.get_pressed()
        if key[pygame.K_w]:
            dx += speed_cos
            dy += speed_sin
        if key[pygame.K_a]:
            dx += speed_sin
            dy += -speed_cos
        if key[pygame.K_s]:
            dx += -speed_cos
            dy += -speed_sin
        if key[pygame.K_d]:
            dx += -speed_sin
            dy += speed_cos
        
        self.check_wall_collision(dx, dy)
        
        self.Angle %= math.tau
        
    def mouse_control(self):
        mx, my = pygame.mouse.get_pos()
        if mx < MOUSE_BOARDER_LEFT or mx > MOUSE_BOARDER_RIGHT:
            pygame.mouse.set_pos([HALF_WIDTH, HALF_HEIGHT])
        self.rel = pygame.mouse.get_rel()[0]
        self.rel = max(-MOUSE_MAX_REL, min(MOUSE_MAX_REL, self.rel))
        self.Angle += self.rel * MOUSE_SENSITIVITY * self.game.delta_time
        
    def check_wall(self, x, y):
        return (x, y) not in self.game.map.world_map
    
    def check_wall_collision(self, dx, dy):
        scale = Player_Size_Scale / self.game.delta_time
        if self.check_wall(int(self.X + dx * scale), int(self.Y)):
            self.X += dx
        if self.check_wall(int(self.X), int(self.Y + dy * scale)):
            self.Y += dy
        
    def draw(self):
        pygame.draw.line(self.game.screen, 'yellow', (self.X*100, self.Y*100),
                     (self.X*100 + WIDTH*math.cos(self.Angle),
                     self.Y*100 + WIDTH*math.sin(self.Angle)), 2)
        pygame.draw.circle(self.game.screen, 'green', (self.X*100, self.Y*100), 15)
    
    def update(self):
        self.movement()
        self.mouse_control()
        
    @property
    def pos(self):
        return self.X, self.Y
    
    @property
    def map_pos(self):
        return int(self.X), int(self.Y)
