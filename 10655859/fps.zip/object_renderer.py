import pygame
from settings import *

class ObjectRenderer:
    def __init__(self, game):
        self.game = game
        self.wall_texture = self.load_wall_texture()
        self.sky_texture = self.get_texture('resources/sky.png', (WIDTH, HALF_HEIGHT))
        self.sky_offset = 0
        
    def draw(self):
        self.render_background()
        self.render_game_object()
        
    def render_background(self):
        self.sky_offset = (self.sky_offset + 4.0 * self.game.player.rel) % WIDTH
        self.game.screen.blit(self.sky_texture, (-self.sky_offset, 0))
        self.game.screen.blit(self.sky_texture, (-self.sky_offset + WIDTH, 0))
        pygame.draw.rect(self.game.screen, FLOOR, (0, HALF_HEIGHT, WIDTH, HEIGHT))
        
    def render_game_object(self):
        list_object = sorted(self.game.raycasting.objects_to_render, key=lambda t: t[0], reverse=True)
        for depth, image, pos in list_object:
            self.game.screen.blit(image, pos)
        
    @staticmethod
    def get_texture(path, res=(TEXTURE_SIZE, TEXTURE_SIZE)):
        texture = pygame.image.load(path).convert_alpha()
        return pygame.transform.scale(texture, res)
    
    def load_wall_texture(self):
        return{
            1:self.get_texture('resources/wall.png')
            }