import pygame
from sprite_object import *

class ObjectList:
    def __init__(self, game):
        self.game = game
        self.sprite_list = []
        self.anim_sprite_path = 'resources/sprites/objects/'
        
        self.add_sprite(AnimatedObject(game, path=self.anim_sprite_path+'0.png', pos=(5.5, 3.5)))
        self.add_sprite(AnimatedObject(game, path=self.anim_sprite_path+'0.png', pos=(5.5, 4.5)))
        self.add_sprite(AnimatedObject(game, path=self.anim_sprite_path+'0.png', pos=(11.5, 3.5)))
        self.add_sprite(AnimatedObject(game, path=self.anim_sprite_path+'0.png', pos=(13.5, 7.5)))
        self.add_sprite(AnimatedObject(game, path=self.anim_sprite_path+'0.png', pos=(6.5, 7.5)))
        
    def update(self):
        [sprite.update() for sprite in self.sprite_list]
    
    def add_sprite(self, sprite):
        self.sprite_list.append(sprite)